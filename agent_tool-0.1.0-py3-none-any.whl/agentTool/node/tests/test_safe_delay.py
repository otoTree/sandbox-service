#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SafeDelay 功能测试脚本
测试安全延时器的各种功能和安全特性
"""

import sys
import os
from pathlib import Path

# 添加父目录到路径以导入模块
sys.path.append(str(Path(__file__).parent.parent))

from system import SafeDelay, safe_delay, progressive_delay
import time


def test_basic_delay():
    """测试基本延时功能"""
    print("=== 测试基本延时功能 ===")
    
    # 测试正常延时
    result = safe_delay(0.1, "基本延时测试")
    print(f"基本延时结果: {result}")
    assert result['success'] == True
    assert 0.09 <= result['actual_delay'] <= 0.15  # 允许一定误差
    
    # 测试带日志的延时
    delay_manager = SafeDelay(log_delays=True)
    result = delay_manager.delay(0.05, "带日志的延时")
    print(f"带日志延时结果: {result}")
    
    print("✓ 基本延时功能测试通过\n")


def test_parameter_validation():
    """测试参数验证"""
    print("=== 测试参数验证 ===")
    
    delay_manager = SafeDelay()
    
    # 测试负数延时
    try:
        delay_manager.delay(-1)
        assert False, "应该抛出ValueError"
    except ValueError as e:
        print(f"✓ 负数延时正确抛出异常: {e}")
    
    # 测试非数字类型
    try:
        delay_manager.delay("invalid")
        assert False, "应该抛出TypeError"
    except TypeError as e:
        print(f"✓ 非数字类型正确抛出异常: {e}")
    
    # 测试超过最大延时
    try:
        delay_manager.delay(400)  # 超过默认的300秒限制
        assert False, "应该抛出ValueError"
    except ValueError as e:
        print(f"✓ 超过最大延时正确抛出异常: {e}")
    
    # 测试过小的延时（应该被自动调整）
    result = delay_manager.delay(0.0001)
    print(f"✓ 过小延时被自动调整: {result['requested_delay']}")
    
    print("✓ 参数验证测试通过\n")


def test_progressive_delay():
    """测试渐进式延时"""
    print("=== 测试渐进式延时 ===")
    
    results = progressive_delay(0.01, max_attempts=3, multiplier=2.0, log_delays=True)
    print(f"渐进式延时结果数量: {len(results)}")
    
    expected_delays = [0.01, 0.02, 0.04]
    for i, result in enumerate(results):
        print(f"第 {i+1} 次延时: 请求 {result['requested_delay']} 秒, 实际 {result['actual_delay']:.3f} 秒")
        assert abs(result['requested_delay'] - expected_delays[i]) < 0.001
    
    print("✓ 渐进式延时测试通过\n")


def test_statistics():
    """测试统计功能"""
    print("=== 测试统计功能 ===")
    
    delay_manager = SafeDelay()
    
    # 执行几次延时
    delay_manager.delay(0.01, "统计测试1")
    delay_manager.delay(0.02, "统计测试2")
    delay_manager.delay(0.03, "统计测试3")
    
    stats = delay_manager.get_stats()
    print(f"统计信息: {stats}")
    
    assert stats['total_delays'] == 3
    assert stats['total_delay_time'] > 0.05
    assert stats['average_delay'] > 0.01
    
    # 重置统计
    delay_manager.reset_stats()
    stats_after_reset = delay_manager.get_stats()
    print(f"重置后统计: {stats_after_reset}")
    
    assert stats_after_reset['total_delays'] == 0
    assert stats_after_reset['total_delay_time'] == 0.0
    
    print("✓ 统计功能测试通过\n")


def test_interruption_support():
    """测试中断支持（模拟测试）"""
    print("=== 测试中断支持 ===")
    
    delay_manager = SafeDelay(allow_interruption=True, log_delays=True)
    
    # 测试短延时（不会分段）
    result = delay_manager.delay(0.5, "短延时测试")
    print(f"短延时结果: {result['success']}")
    
    # 测试长延时（会分段执行）
    start_time = time.time()
    result = delay_manager.delay(2.0, "长延时测试")
    actual_time = time.time() - start_time
    print(f"长延时结果: 成功={result['success']}, 实际用时={actual_time:.3f}秒")
    
    print("✓ 中断支持测试通过\n")


def test_edge_cases():
    """测试边界情况"""
    print("=== 测试边界情况 ===")
    
    # 测试最小延时
    result = safe_delay(SafeDelay.MIN_DELAY_SECONDS)
    print(f"最小延时测试: {result['success']}")
    
    # 测试零延时（会被调整为最小值）
    result = safe_delay(0)
    print(f"零延时测试: 请求={result['requested_delay']}, 实际={result['actual_delay']:.6f}")
    
    # 测试最大允许延时
    delay_manager = SafeDelay(max_delay=1.0)
    result = delay_manager.delay(1.0, "最大延时测试")
    print(f"最大延时测试: {result['success']}")
    
    print("✓ 边界情况测试通过\n")


def main():
    """运行所有测试"""
    print("开始 SafeDelay 功能测试...\n")
    
    try:
        test_basic_delay()
        test_parameter_validation()
        test_progressive_delay()
        test_statistics()
        test_interruption_support()
        test_edge_cases()
        
        print("🎉 所有测试通过！SafeDelay 功能正常工作。")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)