from typing import Dict, List, Optional, Union, Callable, Any
import time
import logging


class LoopWrapper:
    """
    循环执行器封装类
    提供循环执行功能，支持最大次数限制、延迟、异常处理等
    """
    
    def __init__(self, max_iterations: int = 50, delay: float = 0.0, 
                 stop_on_error: bool = False, log_progress: bool = False):
        """
        初始化循环封装器
        
        Args:
            max_iterations: 最大循环次数，默认50次
            delay: 每次循环间的延迟时间（秒），默认0
            stop_on_error: 遇到异常时是否停止循环，默认False
            log_progress: 是否记录循环进度，默认False
        """
        if max_iterations <= 0 or max_iterations > 50:
            raise ValueError("max_iterations must be between 1 and 50")
        
        self.max_iterations = max_iterations
        self.delay = delay
        self.stop_on_error = stop_on_error
        self.log_progress = log_progress
        self.current_iteration = 0
        self.errors = []
        self.results = []
        
        if self.log_progress:
            logging.basicConfig(level=logging.INFO)
            self.logger = logging.getLogger(__name__)
    
    def execute(self, func: Callable, *args, **kwargs) -> Dict[str, Any]:
        """
        执行循环
        
        Args:
            func: 要循环执行的函数
            *args: 传递给函数的位置参数
            **kwargs: 传递给函数的关键字参数
            
        Returns:
            Dict包含执行结果、错误信息、统计数据等
        """
        self.current_iteration = 0
        self.errors = []
        self.results = []
        start_time = time.time()
        
        for i in range(self.max_iterations):
            self.current_iteration = i + 1
            
            if self.log_progress:
                self.logger.info(f"执行第 {self.current_iteration}/{self.max_iterations} 次循环")
            
            try:
                result = func(*args, **kwargs)
                self.results.append({
                    'iteration': self.current_iteration,
                    'result': result,
                    'timestamp': time.time()
                })
                
                # 如果函数返回False或None，可以选择提前结束
                if result is False:
                    if self.log_progress:
                        self.logger.info(f"函数返回False，在第 {self.current_iteration} 次循环后提前结束")
                    break
                    
            except Exception as e:
                error_info = {
                    'iteration': self.current_iteration,
                    'error': str(e),
                    'error_type': type(e).__name__,
                    'timestamp': time.time()
                }
                self.errors.append(error_info)
                
                if self.log_progress:
                    self.logger.error(f"第 {self.current_iteration} 次循环出现错误: {e}")
                
                if self.stop_on_error:
                    if self.log_progress:
                        self.logger.info(f"遇到错误，在第 {self.current_iteration} 次循环后停止")
                    break
            
            # 添加延迟
            if self.delay > 0 and self.current_iteration < self.max_iterations:
                time.sleep(self.delay)
        
        end_time = time.time()
        
        return {
            'total_iterations': self.current_iteration,
            'max_iterations': self.max_iterations,
            'results': self.results,
            'errors': self.errors,
            'success_count': len(self.results),
            'error_count': len(self.errors),
            'execution_time': end_time - start_time,
            'completed': self.current_iteration == self.max_iterations or 
                        (self.results and self.results[-1]['result'] is False)
        }
    
    def execute_with_condition(self, func: Callable, condition: Callable, 
                             *args, **kwargs) -> Dict[str, Any]:
        """
        带条件的循环执行
        
        Args:
            func: 要循环执行的函数
            condition: 条件函数，返回True时继续循环，False时停止
            *args: 传递给函数的位置参数
            **kwargs: 传递给函数的关键字参数
            
        Returns:
            Dict包含执行结果、错误信息、统计数据等
        """
        self.current_iteration = 0
        self.errors = []
        self.results = []
        start_time = time.time()
        
        for i in range(self.max_iterations):
            self.current_iteration = i + 1
            
            # 检查条件
            try:
                if not condition():
                    if self.log_progress:
                        self.logger.info(f"条件不满足，在第 {self.current_iteration} 次循环前停止")
                    break
            except Exception as e:
                error_info = {
                    'iteration': self.current_iteration,
                    'error': f"条件检查失败: {str(e)}",
                    'error_type': 'ConditionError',
                    'timestamp': time.time()
                }
                self.errors.append(error_info)
                if self.stop_on_error:
                    break
            
            if self.log_progress:
                self.logger.info(f"执行第 {self.current_iteration}/{self.max_iterations} 次循环")
            
            try:
                result = func(*args, **kwargs)
                self.results.append({
                    'iteration': self.current_iteration,
                    'result': result,
                    'timestamp': time.time()
                })
                    
            except Exception as e:
                error_info = {
                    'iteration': self.current_iteration,
                    'error': str(e),
                    'error_type': type(e).__name__,
                    'timestamp': time.time()
                }
                self.errors.append(error_info)
                
                if self.log_progress:
                    self.logger.error(f"第 {self.current_iteration} 次循环出现错误: {e}")
                
                if self.stop_on_error:
                    break
            
            # 添加延迟
            if self.delay > 0 and self.current_iteration < self.max_iterations:
                time.sleep(self.delay)
        
        end_time = time.time()
        
        return {
            'total_iterations': self.current_iteration,
            'max_iterations': self.max_iterations,
            'results': self.results,
            'errors': self.errors,
            'success_count': len(self.results),
            'error_count': len(self.errors),
            'execution_time': end_time - start_time,
            'completed': self.current_iteration == self.max_iterations
        }
    
    def reset(self):
        """重置循环状态"""
        self.current_iteration = 0
        self.errors = []
        self.results = []
    
    def get_stats(self) -> Dict[str, Any]:
        """获取当前统计信息"""
        return {
            'current_iteration': self.current_iteration,
            'max_iterations': self.max_iterations,
            'success_count': len(self.results),
            'error_count': len(self.errors),
            'success_rate': len(self.results) / max(self.current_iteration, 1) * 100
        }


# 便捷函数
def loop_execute(func: Callable, max_iterations: int = 50, delay: float = 0.0,
                stop_on_error: bool = False, log_progress: bool = False,
                *args, **kwargs) -> Dict[str, Any]:
    """
    便捷的循环执行函数
    
    Args:
        func: 要循环执行的函数
        max_iterations: 最大循环次数
        delay: 循环间延迟
        stop_on_error: 遇到错误是否停止
        log_progress: 是否记录进度
        *args: 传递给函数的位置参数
        **kwargs: 传递给函数的关键字参数
        
    Returns:
        执行结果字典
    """
    wrapper = LoopWrapper(max_iterations, delay, stop_on_error, log_progress)
    return wrapper.execute(func, *args, **kwargs)


def loop_execute_with_condition(func: Callable, condition: Callable,
                               max_iterations: int = 50, delay: float = 0.0,
                               stop_on_error: bool = False, log_progress: bool = False,
                               *args, **kwargs) -> Dict[str, Any]:
    """
    带条件的便捷循环执行函数
    
    Args:
        func: 要循环执行的函数
        condition: 条件函数
        max_iterations: 最大循环次数
        delay: 循环间延迟
        stop_on_error: 遇到错误是否停止
        log_progress: 是否记录进度
        *args: 传递给函数的位置参数
        **kwargs: 传递给函数的关键字参数
        
    Returns:
        执行结果字典
    """
    wrapper = LoopWrapper(max_iterations, delay, stop_on_error, log_progress)
    return wrapper.execute_with_condition(func, condition, *args, **kwargs)


class SafeDelay:
    """
    安全的延时器类
    提供安全的延时功能，包含参数验证、中断处理、超时限制等安全特性
    """
    
    # 最大允许的延时时间（秒）
    MAX_DELAY_SECONDS = 3600  # 1小时
    MIN_DELAY_SECONDS = 0.001  # 1毫秒
    
    def __init__(self, max_delay: float = 300.0, allow_interruption: bool = True,
                 log_delays: bool = False):
        """
        初始化安全延时器
        
        Args:
            max_delay: 单次延时的最大允许时间（秒），默认300秒（5分钟）
            allow_interruption: 是否允许中断延时，默认True
            log_delays: 是否记录延时日志，默认False
        """
        if max_delay <= 0 or max_delay > self.MAX_DELAY_SECONDS:
            raise ValueError(f"max_delay must be between {self.MIN_DELAY_SECONDS} and {self.MAX_DELAY_SECONDS}")
        
        self.max_delay = max_delay
        self.allow_interruption = allow_interruption
        self.log_delays = log_delays
        self.total_delay_time = 0.0
        self.delay_count = 0
        
        if self.log_delays:
            logging.basicConfig(level=logging.INFO)
            self.logger = logging.getLogger(__name__)
    
    def delay(self, seconds: float, description: str = "") -> Dict[str, Any]:
        """
        执行安全延时
        
        Args:
            seconds: 延时时间（秒）
            description: 延时描述，用于日志记录
            
        Returns:
            Dict包含延时执行结果和统计信息
            
        Raises:
            ValueError: 当延时参数无效时
            TypeError: 当参数类型错误时
        """
        # 参数验证
        if not isinstance(seconds, (int, float)):
            raise TypeError("延时时间必须是数字类型")
        
        if seconds < 0:
            raise ValueError("延时时间不能为负数")
        
        if seconds < self.MIN_DELAY_SECONDS:
            if self.log_delays:
                self.logger.warning(f"延时时间 {seconds} 秒过小，调整为最小值 {self.MIN_DELAY_SECONDS} 秒")
            seconds = self.MIN_DELAY_SECONDS
        
        if seconds > self.max_delay:
            raise ValueError(f"延时时间 {seconds} 秒超过最大允许值 {self.max_delay} 秒")
        
        start_time = time.time()
        
        if self.log_delays:
            desc_msg = f" ({description})" if description else ""
            self.logger.info(f"开始延时 {seconds} 秒{desc_msg}")
        
        try:
            # 执行延时
            if self.allow_interruption and seconds > 1.0:
                # 对于较长的延时，分段执行以支持中断
                remaining_time = seconds
                chunk_size = min(1.0, seconds / 10)  # 每次最多延时1秒或总时间的1/10
                
                while remaining_time > 0:
                    current_delay = min(chunk_size, remaining_time)
                    time.sleep(current_delay)
                    remaining_time -= current_delay
            else:
                # 短延时直接执行
                time.sleep(seconds)
            
            actual_delay = time.time() - start_time
            self.total_delay_time += actual_delay
            self.delay_count += 1
            
            if self.log_delays:
                self.logger.info(f"延时完成，实际用时 {actual_delay:.3f} 秒")
            
            return {
                'success': True,
                'requested_delay': seconds,
                'actual_delay': actual_delay,
                'description': description,
                'timestamp': time.time(),
                'total_delays': self.delay_count,
                'total_delay_time': self.total_delay_time
            }
            
        except KeyboardInterrupt:
            actual_delay = time.time() - start_time
            if self.log_delays:
                self.logger.warning(f"延时被中断，已执行 {actual_delay:.3f} 秒")
            
            return {
                'success': False,
                'interrupted': True,
                'requested_delay': seconds,
                'actual_delay': actual_delay,
                'description': description,
                'timestamp': time.time(),
                'total_delays': self.delay_count,
                'total_delay_time': self.total_delay_time
            }
        
        except Exception as e:
            actual_delay = time.time() - start_time
            if self.log_delays:
                self.logger.error(f"延时执行出错: {e}")
            
            return {
                'success': False,
                'error': str(e),
                'error_type': type(e).__name__,
                'requested_delay': seconds,
                'actual_delay': actual_delay,
                'description': description,
                'timestamp': time.time(),
                'total_delays': self.delay_count,
                'total_delay_time': self.total_delay_time
            }
    
    def progressive_delay(self, base_delay: float, max_attempts: int = 5, 
                         multiplier: float = 2.0, max_delay: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        渐进式延时（指数退避）
        
        Args:
            base_delay: 基础延时时间（秒）
            max_attempts: 最大尝试次数
            multiplier: 延时倍增因子
            max_delay: 单次延时的最大时间，默认使用实例的max_delay
            
        Returns:
            List[Dict] 每次延时的结果
        """
        if max_delay is None:
            max_delay = self.max_delay
        
        results = []
        current_delay = base_delay
        
        for attempt in range(max_attempts):
            # 确保不超过最大延时限制
            actual_delay = min(current_delay, max_delay)
            
            result = self.delay(actual_delay, f"渐进式延时第 {attempt + 1} 次")
            results.append(result)
            
            # 如果延时被中断或出错，停止后续延时
            if not result['success']:
                break
            
            # 计算下次延时时间
            current_delay *= multiplier
        
        return results
    
    def reset_stats(self):
        """重置统计信息"""
        self.total_delay_time = 0.0
        self.delay_count = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """获取延时统计信息"""
        avg_delay = self.total_delay_time / max(self.delay_count, 1)
        
        return {
            'total_delays': self.delay_count,
            'total_delay_time': self.total_delay_time,
            'average_delay': avg_delay,
            'max_allowed_delay': self.max_delay,
            'interruption_enabled': self.allow_interruption,
            'logging_enabled': self.log_delays
        }


# 便捷函数
def safe_delay(seconds: float, description: str = "", max_delay: float = 300.0,
               allow_interruption: bool = True, log_delays: bool = False) -> Dict[str, Any]:
    """
    便捷的安全延时函数
    
    Args:
        seconds: 延时时间（秒）
        description: 延时描述
        max_delay: 最大允许延时时间
        allow_interruption: 是否允许中断
        log_delays: 是否记录日志
        
    Returns:
        延时执行结果
    """
    delay_manager = SafeDelay(max_delay, allow_interruption, log_delays)
    return delay_manager.delay(seconds, description)


def progressive_delay(base_delay: float, max_attempts: int = 5, multiplier: float = 2.0,
                     max_delay: float = 300.0, allow_interruption: bool = True,
                     log_delays: bool = False) -> List[Dict[str, Any]]:
    """
    便捷的渐进式延时函数
    
    Args:
        base_delay: 基础延时时间（秒）
        max_attempts: 最大尝试次数
        multiplier: 延时倍增因子
        max_delay: 最大延时时间
        allow_interruption: 是否允许中断
        log_delays: 是否记录日志
        
    Returns:
        每次延时的结果列表
    """
    delay_manager = SafeDelay(max_delay, allow_interruption, log_delays)
    return delay_manager.progressive_delay(base_delay, max_attempts, multiplier, max_delay)


