"""
AgentTool - A Python agent tool package with data processing capabilities

This package provides utilities for data processing, web requests, and analysis
using popular libraries like requests, numpy, and pandas.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# Import main functionality
from .node.httpClient import HttpClient

def get_version():
    """
    Get the current version of the package.
    
    Returns:
        str: The version string
    """
    return __version__

def hello_agent():
    """
    A simple greeting function for the agent tool.
    
    Returns:
        str: A greeting message
    """
    return "Hello! This is AgentTool - your data processing companion."

# Define what gets imported when someone does "from agentTool import *"
__all__ = [
    "HttpClient",
]