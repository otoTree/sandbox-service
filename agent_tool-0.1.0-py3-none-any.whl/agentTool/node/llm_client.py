#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM客户端
支持多种LLM API，包括OpenAI、Claude、本地模型等
提供统一的接口和丰富的功能
"""

from typing import Dict, List, Optional, Union, Any, Callable
import json
import time
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
import base64
import os
from pathlib import Path

from .httpClient import HttpClient
from .system import SafeDelay, LoopWrapper


class LLMProvider(Enum):
    """LLM提供商枚举"""
    OPENAI = "openai"
    CLAUDE = "claude"
    GEMINI = "gemini"
    LOCAL = "local"
    CUSTOM = "custom"


class MessageRole(Enum):
    """消息角色枚举"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    FUNCTION = "function"


@dataclass
class Message:
    """消息数据类"""
    role: MessageRole
    content: str
    name: Optional[str] = None
    function_call: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    """LLM配置数据类"""
    provider: LLMProvider
    api_key: str
    base_url: str
    model: str
    max_tokens: int = 4096
    temperature: float = 0.7
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    timeout: int = 60
    retry_attempts: int = 3
    retry_delay: float = 1.0
    headers: Dict[str, str] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """LLM响应数据类"""
    content: str
    model: str
    usage: Dict[str, int]
    finish_reason: str
    response_time: float
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseLLMClient(ABC):
    """LLM客户端基类"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self.http_client = HttpClient(
            base_url=config.base_url,
            headers=self._build_headers(),
            timeout=config.timeout
        )
        self.safe_delay = SafeDelay(max_delay=300.0, log_delays=True)
        self.logger = logging.getLogger(f"{__name__}.{config.provider.value}")
        
    def _build_headers(self) -> Dict[str, str]:
        """构建请求头"""
        headers = {
            "Content-Type": "application/json",
            **self.config.headers
        }
        return headers
    
    @abstractmethod
    def _format_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """格式化消息为API特定格式"""
        pass
    
    @abstractmethod
    def _build_request_payload(self, messages: List[Message], **kwargs) -> Dict[str, Any]:
        """构建请求载荷"""
        pass
    
    @abstractmethod
    def _parse_response(self, response_data: Dict[str, Any]) -> LLMResponse:
        """解析API响应"""
        pass
    
    def chat(self, messages: List[Message], **kwargs) -> LLMResponse:
        """发送聊天请求"""
        start_time = time.time()
        
        try:
            payload = self._build_request_payload(messages, **kwargs)
            
            # 直接发送请求，不使用LoopWrapper的复杂结构
            response = self.http_client.post(json_data=payload)
            if response.status_code != 200:
                raise Exception(f"API请求失败: {response.status_code} - {response.text}")
            
            response_data = response.json()
            response_time = time.time() - start_time
            
            llm_response = self._parse_response(response_data)
            llm_response.response_time = response_time
            
            return llm_response
            
        except Exception as e:
            self.logger.error(f"聊天请求失败: {e}")
            raise
    
    def encode_image(self, image_path: str) -> str:
        """编码图像为base64"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图像文件不存在: {image_path}")
        
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    
    def create_image_message(self, text: str, image_path: str) -> Message:
        """创建包含图像的消息"""
        image_base64 = self.encode_image(image_path)
        image_ext = Path(image_path).suffix.lower()
        mime_type = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp'
        }.get(image_ext, 'image/jpeg')
        
        content = [
            {"type": "text", "text": text},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:{mime_type};base64,{image_base64}"
                }
            }
        ]
        
        return Message(
            role=MessageRole.USER,
            content=json.dumps(content),
            metadata={"has_image": True, "image_path": image_path}
        )


class OpenAIClient(BaseLLMClient):
    """OpenAI客户端实现"""
    
    def __init__(self, api_key: str, model: str = "gpt-3.5-turbo", 
                 base_url: str = "https://api.openai.com/v1/chat/completions"):
        config = LLMConfig(
            provider=LLMProvider.OPENAI,
            api_key=api_key,
            base_url=base_url,
            model=model,
            headers={"Authorization": f"Bearer {api_key}"}
        )
        super().__init__(config)
    
    def _format_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """格式化消息为OpenAI格式"""
        formatted = []
        for msg in messages:
            formatted_msg = {
                "role": msg.role.value,
                "content": msg.content
            }
            if msg.name:
                formatted_msg["name"] = msg.name
            if msg.function_call:
                formatted_msg["function_call"] = msg.function_call
            formatted.append(formatted_msg)
        return formatted
    
    def _build_request_payload(self, messages: List[Message], **kwargs) -> Dict[str, Any]:
        """构建OpenAI请求载荷"""
        payload = {
            "model": self.config.model,
            "messages": self._format_messages(messages),
            "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
            "temperature": kwargs.get("temperature", self.config.temperature),
            "top_p": kwargs.get("top_p", self.config.top_p),
            "frequency_penalty": kwargs.get("frequency_penalty", self.config.frequency_penalty),
            "presence_penalty": kwargs.get("presence_penalty", self.config.presence_penalty),
        }
        
        # 添加其他可选参数
        if "functions" in kwargs:
            payload["functions"] = kwargs["functions"]
        if "function_call" in kwargs:
            payload["function_call"] = kwargs["function_call"]
        if "stream" in kwargs:
            payload["stream"] = kwargs["stream"]
            
        return payload
    
    def _parse_response(self, response_data: Dict[str, Any]) -> LLMResponse:
        """解析OpenAI响应"""
        choice = response_data["choices"][0]
        message = choice["message"]
        
        return LLMResponse(
            content=message.get("content", ""),
            model=response_data["model"],
            usage=response_data.get("usage", {}),
            finish_reason=choice.get("finish_reason", ""),
            response_time=0.0,  # 将在调用处设置
            metadata={
                "function_call": message.get("function_call"),
                "raw_response": response_data
            }
        )


class ClaudeClient(BaseLLMClient):
    """Claude客户端实现"""
    
    def __init__(self, api_key: str, model: str = "claude-3-sonnet-20240229",
                 base_url: str = "https://api.anthropic.com/v1/messages"):
        config = LLMConfig(
            provider=LLMProvider.CLAUDE,
            api_key=api_key,
            base_url=base_url,
            model=model,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01"
            }
        )
        super().__init__(config)
    
    def _format_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """格式化消息为Claude格式"""
        formatted = []
        for msg in messages:
            if msg.role == MessageRole.SYSTEM:
                continue  # Claude的system消息单独处理
            
            formatted_msg = {
                "role": msg.role.value,
                "content": msg.content
            }
            formatted.append(formatted_msg)
        return formatted
    
    def _build_request_payload(self, messages: List[Message], **kwargs) -> Dict[str, Any]:
        """构建Claude请求载荷"""
        # 提取system消息
        system_message = ""
        for msg in messages:
            if msg.role == MessageRole.SYSTEM:
                system_message = msg.content
                break
        
        payload = {
            "model": self.config.model,
            "messages": self._format_messages(messages),
            "max_tokens": kwargs.get("max_tokens", self.config.max_tokens),
            "temperature": kwargs.get("temperature", self.config.temperature),
            "top_p": kwargs.get("top_p", self.config.top_p),
        }
        
        if system_message:
            payload["system"] = system_message
            
        return payload
    
    def _parse_response(self, response_data: Dict[str, Any]) -> LLMResponse:
        """解析Claude响应"""
        content = response_data["content"][0]["text"]
        
        return LLMResponse(
            content=content,
            model=response_data["model"],
            usage=response_data.get("usage", {}),
            finish_reason=response_data.get("stop_reason", ""),
            response_time=0.0,
            metadata={"raw_response": response_data}
        )


class LocalLLMClient(BaseLLMClient):
    """本地LLM客户端实现（如Ollama等）"""
    
    def __init__(self, base_url: str, model: str, api_key: str = ""):
        config = LLMConfig(
            provider=LLMProvider.LOCAL,
            api_key=api_key,
            base_url=base_url,
            model=model
        )
        super().__init__(config)
    
    def _format_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """格式化消息为本地模型格式"""
        return [{"role": msg.role.value, "content": msg.content} for msg in messages]
    
    def _build_request_payload(self, messages: List[Message], **kwargs) -> Dict[str, Any]:
        """构建本地模型请求载荷"""
        return {
            "model": self.config.model,
            "messages": self._format_messages(messages),
            "options": {
                "temperature": kwargs.get("temperature", self.config.temperature),
                "top_p": kwargs.get("top_p", self.config.top_p),
                "num_predict": kwargs.get("max_tokens", self.config.max_tokens),
            }
        }
    
    def _parse_response(self, response_data: Dict[str, Any]) -> LLMResponse:
        """解析本地模型响应"""
        return LLMResponse(
            content=response_data.get("message", {}).get("content", ""),
            model=response_data.get("model", self.config.model),
            usage={},
            finish_reason=response_data.get("done_reason", ""),
            response_time=0.0,
            metadata={"raw_response": response_data}
        )


class LLMClientFactory:
    """LLM客户端工厂类"""
    
    @staticmethod
    def create_client(provider: LLMProvider, **kwargs) -> BaseLLMClient:
        """创建LLM客户端"""
        if provider == LLMProvider.OPENAI:
            return OpenAIClient(**kwargs)
        elif provider == LLMProvider.CLAUDE:
            return ClaudeClient(**kwargs)
        elif provider == LLMProvider.LOCAL:
            return LocalLLMClient(**kwargs)
        else:
            raise ValueError(f"不支持的LLM提供商: {provider}")
    
    @staticmethod
    def create_openai_client(api_key: str, model: str = "gpt-3.5-turbo") -> OpenAIClient:
        """创建OpenAI客户端"""
        return OpenAIClient(api_key=api_key, model=model)
    
    @staticmethod
    def create_claude_client(api_key: str, model: str = "claude-3-sonnet-20240229") -> ClaudeClient:
        """创建Claude客户端"""
        return ClaudeClient(api_key=api_key, model=model)
    
    @staticmethod
    def create_local_client(base_url: str, model: str) -> LocalLLMClient:
        """创建本地模型客户端"""
        return LocalLLMClient(base_url=base_url, model=model)


# 便捷函数
def create_message(role: str, content: str, **kwargs) -> Message:
    """创建消息的便捷函数"""
    return Message(
        role=MessageRole(role),
        content=content,
        name=kwargs.get("name"),
        function_call=kwargs.get("function_call"),
        metadata=kwargs.get("metadata", {})
    )


def create_conversation(system_prompt: str = "") -> List[Message]:
    """创建对话的便捷函数"""
    messages = []
    if system_prompt:
        messages.append(create_message("system", system_prompt))
    return messages