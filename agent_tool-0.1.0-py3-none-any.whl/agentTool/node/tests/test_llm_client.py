#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM客户端测试文件
包含单元测试和集成测试
"""

import unittest
import os
import json
import tempfile
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path
import sys

# 添加父目录到路径以导入模块
sys.path.append(str(Path(__file__).parent.parent))

# 导入要测试的模块
from llm_client import (
    Message, LLMConfig, LLMResponse, MessageRole,
    OpenAIClient, ClaudeClient, LocalLLMClient, LLMClientFactory,
    create_message, create_conversation
)
from llm_multimodal import (
    MediaType, MediaContent, MultiModalMessage, MediaProcessor,
    MultiModalClient, create_image_message, create_mixed_message
)


class TestMessage(unittest.TestCase):
    """测试Message类"""
    
    def test_message_creation(self):
        """测试消息创建"""
        msg = Message(role=MessageRole.USER, content="Hello")
        self.assertEqual(msg.role, MessageRole.USER)
        self.assertEqual(msg.content, "Hello")
        self.assertIsNone(msg.metadata)
    
    def test_message_with_metadata(self):
        """测试带元数据的消息"""
        metadata = {"timestamp": "2024-01-01"}
        msg = Message(role=MessageRole.ASSISTANT, content="Hi", metadata=metadata)
        self.assertEqual(msg.metadata, metadata)
    
    def test_message_to_dict(self):
        """测试消息转字典"""
        msg = Message(role=MessageRole.USER, content="Test")
        expected = {"role": "user", "content": "Test"}
        self.assertEqual(msg.to_dict(), expected)


class TestLLMConfig(unittest.TestCase):
    """测试LLMConfig类"""
    
    def test_config_creation(self):
        """测试配置创建"""
        config = LLMConfig(
            api_key="test-key",
            model="gpt-3.5-turbo",
            temperature=0.7
        )
        self.assertEqual(config.api_key, "test-key")
        self.assertEqual(config.model, "gpt-3.5-turbo")
        self.assertEqual(config.temperature, 0.7)
    
    def test_config_defaults(self):
        """测试默认配置"""
        config = LLMConfig(api_key="test-key")
        self.assertEqual(config.temperature, 0.7)
        self.assertEqual(config.max_tokens, 1000)


class TestLLMResponse(unittest.TestCase):
    """测试LLMResponse类"""
    
    def test_response_creation(self):
        """测试响应创建"""
        response = LLMResponse(
            content="Hello world",
            model="gpt-3.5-turbo",
            usage={"total_tokens": 10},
            response_time=1.5
        )
        self.assertEqual(response.content, "Hello world")
        self.assertEqual(response.model, "gpt-3.5-turbo")
        self.assertEqual(response.usage["total_tokens"], 10)
        self.assertEqual(response.response_time, 1.5)


class TestOpenAIClient(unittest.TestCase):
    """测试OpenAI客户端"""
    
    def setUp(self):
        """设置测试"""
        self.client = OpenAIClient(
            api_key="test-key",
            model="gpt-3.5-turbo"
        )
    
    @patch('httpClient.HttpClient.post')
    def test_chat_success(self, mock_post):
        """测试成功的聊天请求"""
        # 模拟API响应
        mock_response = Mock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": "Hello! How can I help you?"
                }
            }],
            "model": "gpt-3.5-turbo",
            "usage": {"total_tokens": 20}
        }
        mock_response.status_code = 200
        mock_post.return_value = mock_response
        
        messages = [create_message("user", "Hello")]
        response = self.client.chat(messages)
        
        self.assertEqual(response.content, "Hello! How can I help you?")
        self.assertEqual(response.model, "gpt-3.5-turbo")
    
    @patch('httpClient.HttpClient.post')
    def test_chat_api_error(self, mock_post):
        """测试API错误"""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        mock_post.return_value = mock_response
        
        messages = [create_message("user", "Hello")]
        
        with self.assertRaises(Exception):
            self.client.chat(messages)


class TestClaudeClient(unittest.TestCase):
    """测试Claude客户端"""
    
    def setUp(self):
        """设置测试"""
        self.client = ClaudeClient(
            api_key="test-key",
            model="claude-3-sonnet-20240229"
        )
    
    @patch('httpClient.HttpClient.post')
    def test_chat_success(self, mock_post):
        """测试成功的聊天请求"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "content": [{"text": "Hello from Claude!"}],
            "model": "claude-3-sonnet-20240229",
            "usage": {"input_tokens": 10, "output_tokens": 15}
        }
        mock_response.status_code = 200
        mock_post.return_value = mock_response
        
        messages = [create_message("user", "Hello")]
        response = self.client.chat(messages)
        
        self.assertEqual(response.content, "Hello from Claude!")


class TestLLMClientFactory(unittest.TestCase):
    """测试LLM客户端工厂"""
    
    def test_create_openai_client(self):
        """测试创建OpenAI客户端"""
        client = LLMClientFactory.create_openai_client(
            api_key="test-key",
            model="gpt-4"
        )
        self.assertIsInstance(client, OpenAIClient)
        self.assertEqual(client.config.model, "gpt-4")
    
    def test_create_claude_client(self):
        """测试创建Claude客户端"""
        client = LLMClientFactory.create_claude_client(
            api_key="test-key",
            model="claude-3-opus-20240229"
        )
        self.assertIsInstance(client, ClaudeClient)
        self.assertEqual(client.config.model, "claude-3-opus-20240229")
    
    def test_create_local_client(self):
        """测试创建本地客户端"""
        client = LLMClientFactory.create_local_client(
            base_url="http://localhost:8000",
            model="llama2"
        )
        self.assertIsInstance(client, LocalLLMClient)


class TestMediaContent(unittest.TestCase):
    """测试媒体内容类"""
    
    def test_media_content_creation(self):
        """测试媒体内容创建"""
        content = MediaContent(
            media_type=MediaType.IMAGE,
            data=b"fake_image_data",
            metadata={"format": "png"}
        )
        self.assertEqual(content.media_type, MediaType.IMAGE)
        self.assertEqual(content.data, b"fake_image_data")
        self.assertEqual(content.metadata["format"], "png")


class TestMediaProcessor(unittest.TestCase):
    """测试媒体处理器"""
    
    def setUp(self):
        """设置测试"""
        self.processor = MediaProcessor()
    
    def test_detect_image_type(self):
        """测试图像类型检测"""
        # 创建临时PNG文件
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            f.write(b'\x89PNG\r\n\x1a\n')  # PNG文件头
            temp_file = f.name
        
        try:
            media_type = self.processor.detect_media_type(temp_file)
            self.assertEqual(media_type, MediaType.IMAGE)
        finally:
            os.unlink(temp_file)
    
    def test_detect_text_type(self):
        """测试文本类型检测"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("This is a test file")
            temp_file = f.name
        
        try:
            media_type = self.processor.detect_media_type(temp_file)
            self.assertEqual(media_type, MediaType.TEXT)
        finally:
            os.unlink(temp_file)


class TestMultiModalMessage(unittest.TestCase):
    """测试多模态消息"""
    
    def test_multimodal_message_creation(self):
        """测试多模态消息创建"""
        text_content = MediaContent(MediaType.TEXT, "Hello world")
        image_content = MediaContent(MediaType.IMAGE, b"fake_image")
        
        message = MultiModalMessage(
            role=MessageRole.USER,
            contents=[text_content, image_content]
        )
        
        self.assertEqual(len(message.contents), 2)
        self.assertEqual(message.contents[0].media_type, MediaType.TEXT)
        self.assertEqual(message.contents[1].media_type, MediaType.IMAGE)


class TestMultiModalClient(unittest.TestCase):
    """测试多模态客户端"""
    
    def setUp(self):
        """设置测试"""
        # 创建模拟的基础客户端
        self.base_client = Mock()
        self.base_client.chat.return_value = LLMResponse(
            content="Image analysis result",
            model="gpt-4-vision",
            usage={"total_tokens": 50},
            response_time=2.0
        )
        
        self.multimodal_client = MultiModalClient(self.base_client)
    
    def test_chat_with_image(self):
        """测试图像聊天"""
        # 创建临时图像文件
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            f.write(b'\x89PNG\r\n\x1a\n')  # PNG文件头
            temp_image = f.name
        
        try:
            response = self.multimodal_client.chat_with_image(
                image_path=temp_image,
                prompt="Describe this image"
            )
            
            self.assertEqual(response.content, "Image analysis result")
            self.base_client.chat.assert_called_once()
        finally:
            os.unlink(temp_image)


class TestHelperFunctions(unittest.TestCase):
    """测试辅助函数"""
    
    def test_create_message(self):
        """测试创建消息函数"""
        msg = create_message("user", "Hello")
        self.assertEqual(msg.role, MessageRole.USER)
        self.assertEqual(msg.content, "Hello")
    
    def test_create_conversation(self):
        """测试创建对话函数"""
        conversation = create_conversation("You are a helpful assistant")
        self.assertEqual(len(conversation), 1)
        self.assertEqual(conversation[0].role, MessageRole.SYSTEM)
        self.assertEqual(conversation[0].content, "You are a helpful assistant")
    
    def test_create_image_message(self):
        """测试创建图像消息"""
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            f.write(b'\x89PNG\r\n\x1a\n')
            temp_image = f.name
        
        try:
            message = create_image_message(temp_image, "Analyze this image")
            self.assertIsInstance(message, MultiModalMessage)
            self.assertEqual(len(message.contents), 2)  # 文本 + 图像
        finally:
            os.unlink(temp_image)


class TestIntegration(unittest.TestCase):
    """集成测试"""
    
    @patch('httpClient.HttpClient.post')
    def test_end_to_end_workflow(self, mock_post):
        """测试端到端工作流程"""
        # 模拟API响应
        mock_response = Mock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": "This is a comprehensive response to your question."
                }
            }],
            "model": "gpt-3.5-turbo",
            "usage": {"total_tokens": 50}
        }
        mock_response.status_code = 200
        mock_post.return_value = mock_response
        
        # 创建客户端
        client = LLMClientFactory.create_openai_client(
            api_key="test-key",
            model="gpt-3.5-turbo"
        )
        
        # 创建对话
        conversation = create_conversation("You are a helpful assistant.")
        conversation.append(create_message("user", "What is machine learning?"))
        
        # 发送请求
        response = client.chat(conversation)
        
        # 验证结果
        self.assertIsInstance(response, LLMResponse)
        self.assertIn("comprehensive response", response.content)
        self.assertEqual(response.model, "gpt-3.5-turbo")


class TestPerformance(unittest.TestCase):
    """性能测试"""
    
    def test_message_creation_performance(self):
        """测试消息创建性能"""
        import time
        
        start_time = time.time()
        
        # 创建大量消息
        messages = []
        for i in range(1000):
            msg = create_message("user", f"Message {i}")
            messages.append(msg)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # 应该在合理时间内完成
        self.assertLess(duration, 1.0)  # 1秒内
        self.assertEqual(len(messages), 1000)


class TestMockAPI(unittest.TestCase):
    """模拟API测试"""
    
    def setUp(self):
        """设置模拟API"""
        self.mock_responses = {
            "openai": {
                "choices": [{
                    "message": {"content": "OpenAI response"}
                }],
                "model": "gpt-3.5-turbo",
                "usage": {"total_tokens": 25}
            },
            "claude": {
                "content": [{"text": "Claude response"}],
                "model": "claude-3-sonnet",
                "usage": {"input_tokens": 10, "output_tokens": 15}
            }
        }
    
    @patch('httpClient.HttpClient.post')
    def test_multiple_providers(self, mock_post):
        """测试多个提供商"""
        # 测试OpenAI
        mock_response = Mock()
        mock_response.json.return_value = self.mock_responses["openai"]
        mock_response.status_code = 200
        mock_post.return_value = mock_response
        
        openai_client = LLMClientFactory.create_openai_client("test-key")
        response = openai_client.chat([create_message("user", "Hello")])
        self.assertEqual(response.content, "OpenAI response")
        
        # 测试Claude
        mock_response.json.return_value = self.mock_responses["claude"]
        
        claude_client = LLMClientFactory.create_claude_client("test-key")
        response = claude_client.chat([create_message("user", "Hello")])
        self.assertEqual(response.content, "Claude response")


def run_tests():
    """运行所有测试"""
    # 创建测试套件
    test_suite = unittest.TestSuite()
    
    # 添加测试类
    test_classes = [
        TestMessage,
        TestLLMConfig,
        TestLLMResponse,
        TestOpenAIClient,
        TestClaudeClient,
        TestLLMClientFactory,
        TestMediaContent,
        TestMediaProcessor,
        TestMultiModalMessage,
        TestMultiModalClient,
        TestHelperFunctions,
        TestIntegration,
        TestPerformance,
        TestMockAPI
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # 返回测试结果
    return result.wasSuccessful()


if __name__ == "__main__":
    print("开始运行LLM客户端测试...")
    print("=" * 50)
    
    success = run_tests()
    
    if success:
        print("\n✓ 所有测试通过！")
    else:
        print("\n✗ 部分测试失败，请检查错误信息")
    
    print("测试完成。")