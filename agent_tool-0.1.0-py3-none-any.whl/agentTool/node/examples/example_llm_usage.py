#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM客户端使用示例
演示如何使用LLM客户端的各种功能
"""

import os
import time
import json
from pathlib import Path

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from llm_client import (
    LLMClientFactory, LLMProvider, MessageRole,
    create_message, create_conversation
)
from llm_multimodal import (
    MultiModalClient, MediaProcessor,
    create_image_message, create_mixed_message
)


def example_basic_chat():
    """基础聊天示例"""
    print("=== 基础聊天示例 ===")
    
    # 创建OpenAI客户端（需要设置API密钥）
    api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")
    if api_key == "your-api-key-here":
        print("请设置OPENAI_API_KEY环境变量")
        return
    
    client = LLMClientFactory.create_openai_client(
        api_key=api_key,
        model="gpt-3.5-turbo"
    )
    
    # 创建对话
    messages = create_conversation("你是一个有用的AI助手。")
    messages.append(create_message("user", "你好！请介绍一下自己。"))
    
    try:
        response = client.chat(messages)
        print(f"AI回复: {response.content}")
        print(f"使用的模型: {response.model}")
        print(f"响应时间: {response.response_time:.2f}秒")
        print(f"Token使用: {response.usage}")
    except Exception as e:
        print(f"聊天失败: {e}")


def example_claude_chat():
    """Claude聊天示例"""
    print("\n=== Claude聊天示例 ===")
    
    api_key = os.getenv("CLAUDE_API_KEY", "your-claude-key-here")
    if api_key == "your-claude-key-here":
        print("请设置CLAUDE_API_KEY环境变量")
        return
    
    client = LLMClientFactory.create_claude_client(
        api_key=api_key,
        model="claude-3-sonnet-20240229"
    )
    
    messages = [
        create_message("user", "请用中文回答：什么是人工智能？")
    ]
    
    try:
        response = client.chat(messages)
        print(f"Claude回复: {response.content}")
    except Exception as e:
        print(f"Claude聊天失败: {e}")


def example_local_llm():
    """本地LLM示例"""
    print("\n=== 本地LLM示例 ===")
    
    # 假设你运行了Ollama或其他本地LLM服务
    client = LLMClientFactory.create_local_client(
        base_url="http://localhost:11434/api/chat",
        model="llama2"
    )
    
    messages = [create_message("user", "Hello! How are you?")]
    
    try:
        response = client.chat(messages)
        print(f"本地LLM回复: {response.content}")
    except Exception as e:
        print(f"本地LLM连接失败: {e}")


def example_multimodal_chat():
    """多模态聊天示例"""
    print("\n=== 多模态聊天示例 ===")
    
    api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")
    if api_key == "your-api-key-here":
        print("请设置OPENAI_API_KEY环境变量")
        return
    
    # 创建支持多模态的客户端
    base_client = LLMClientFactory.create_openai_client(
        api_key=api_key,
        model="gpt-4-vision-preview"  # 支持图像的模型
    )
    
    multimodal_client = MultiModalClient(base_client)
    
    # 创建测试图像
    test_image = create_test_image()
    
    try:
        # 图像分析
        response = multimodal_client.chat_with_image(
            image_path=test_image,
            prompt="请描述这张图片的内容"
        )
        print(f"图像分析结果: {response.content}")
        
        # 清理测试文件
        os.remove(test_image)
        
    except Exception as e:
        print(f"多模态聊天失败: {e}")


def example_batch_processing():
    """批量处理示例"""
    print("\n=== 批量处理示例 ===")
    
    api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")
    if api_key == "your-api-key-here":
        print("请设置OPENAI_API_KEY环境变量")
        return
    
    client = LLMClientFactory.create_openai_client(api_key=api_key)
    
    # 批量处理多个问题
    questions = [
        "什么是机器学习？",
        "Python有什么优势？",
        "如何学习编程？"
    ]
    
    print("批量处理问题...")
    for i, question in enumerate(questions, 1):
        try:
            messages = [create_message("user", question)]
            response = client.chat(messages)
            print(f"问题{i}: {question}")
            print(f"回答: {response.content[:100]}...")
            print("-" * 50)
        except Exception as e:
            print(f"处理问题{i}失败: {e}")


def example_conversation_management():
    """对话管理示例"""
    print("\n=== 对话管理示例 ===")
    
    api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")
    if api_key == "your-api-key-here":
        print("请设置OPENAI_API_KEY环境变量")
        return
    
    client = LLMClientFactory.create_openai_client(api_key=api_key)
    
    # 模拟多轮对话
    conversation_history = create_conversation("你是一个友好的助手。")
    
    questions = [
        "我叫张三，很高兴认识你。",
        "我今年25岁，是一名程序员。",
        "你还记得我的名字吗？",
        "我的职业是什么？"
    ]
    
    for question in questions:
        conversation_history.append(create_message("user", question))
        
        try:
            response = client.chat(conversation_history)
            print(f"用户: {question}")
            print(f"AI: {response.content}")
            
            # 将AI回复添加到对话历史
            conversation_history.append(create_message("assistant", response.content))
            print("-" * 50)
            
        except Exception as e:
            print(f"对话失败: {e}")


def create_test_image():
    """创建测试图像文件"""
    from PIL import Image, ImageDraw, ImageFont
    
    # 创建一个简单的测试图像
    img = Image.new('RGB', (400, 200), color='lightblue')
    draw = ImageDraw.Draw(img)
    
    # 添加文本
    try:
        # 尝试使用系统字体
        font = ImageFont.truetype("arial.ttf", 24)
    except:
        # 如果没有找到字体，使用默认字体
        font = ImageFont.load_default()
    
    draw.text((50, 80), "Hello, LLM!", fill='black', font=font)
    draw.rectangle([20, 20, 380, 180], outline='blue', width=3)
    
    # 保存图像
    test_image_path = "test_image.png"
    img.save(test_image_path)
    return test_image_path


def create_test_files():
    """创建测试文件"""
    files = []
    
    # 创建文本文件
    text_file = "test_document.txt"
    with open(text_file, 'w', encoding='utf-8') as f:
        f.write("这是一个测试文档。\n包含一些示例文本内容。")
    files.append(text_file)
    
    # 创建JSON文件
    json_file = "test_data.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump({"name": "测试", "type": "示例", "data": [1, 2, 3]}, f, ensure_ascii=False)
    files.append(json_file)
    
    return files


def cleanup_test_files(file_list):
    """清理测试文件"""
    for file_path in file_list:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"已删除测试文件: {file_path}")
        except Exception as e:
            print(f"删除文件失败 {file_path}: {e}")


def main():
    """主函数 - 运行所有示例"""
    print("LLM客户端使用示例")
    print("=" * 50)
    
    # 可用的示例函数
    examples = [
        ("基础聊天", example_basic_chat),
        ("Claude聊天", example_claude_chat),
        ("本地LLM", example_local_llm),
        ("多模态聊天", example_multimodal_chat),
        ("批量处理", example_batch_processing),
        ("对话管理", example_conversation_management),
    ]
    
    print("可用示例:")
    for i, (name, _) in enumerate(examples, 1):
        print(f"{i}. {name}")
    
    print("\n选择要运行的示例 (输入数字，0运行所有示例):")
    try:
        choice = input("请选择: ").strip()
        
        if choice == "0":
            # 运行所有示例
            for name, func in examples:
                print(f"\n{'='*20} {name} {'='*20}")
                func()
                time.sleep(1)  # 避免API限制
        elif choice.isdigit() and 1 <= int(choice) <= len(examples):
            # 运行选定的示例
            name, func = examples[int(choice) - 1]
            print(f"\n{'='*20} {name} {'='*20}")
            func()
        else:
            print("无效选择")
            
    except KeyboardInterrupt:
        print("\n\n程序被用户中断")
    except Exception as e:
        print(f"\n运行示例时出错: {e}")
    
    print("\n示例运行完成！")


if __name__ == "__main__":
    main()