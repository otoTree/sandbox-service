import requests
from typing import Dict, List, Optional, Union, Any, BinaryIO
import json
import os
import mimetypes
from pathlib import Path
import base64

class HttpClient:
    def __init__(self, base_url: str, headers: Dict[str, str] = None, timeout: int = 60):
        """
        初始化 HttpClient
        
        Args:
            base_url: 基础URL
            headers: 请求头
            timeout: 超时时间（秒）
        """
        self.base_url = base_url
        self.timeout = timeout
        self.headers = headers or {}
        self.session = requests.Session()
        
    def _detect_content_type(self, file_path: str) -> str:
        """检测文件的 MIME 类型"""
        content_type, _ = mimetypes.guess_type(file_path)
        return content_type or 'application/octet-stream'
    
    def _prepare_file_data(self, file_path: str, field_name: str = 'file') -> Dict[str, Any]:
        """准备文件数据用于上传"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        content_type = self._detect_content_type(file_path)
        file_name = os.path.basename(file_path)
        
        return {
            'path': file_path,
            'field_name': field_name,
            'content_type': content_type,
            'file_name': file_name
        }
    
    def post(self, data: Dict[str, Any] = None, json_data: Dict[str, Any] = None, 
             files: Union[str, List[str], Dict[str, str]] = None, 
             form_data: Dict[str, Any] = None) -> requests.Response:
        """
        发送 POST 请求
        
        Args:
            data: 表单数据
            json_data: JSON 数据
            files: 文件路径（字符串、列表或字典）
            form_data: 多部分表单数据
            
        Returns:
            requests.Response 对象
        """
        kwargs = {
            'url': self.base_url,
            'headers': self.headers.copy(),
            'timeout': self.timeout
        }
        
        # 处理文件上传
        if files:
            files_data = {}
            
            if isinstance(files, str):
                # 单个文件
                file_info = self._prepare_file_data(files)
                files_data[file_info['field_name']] = (
                    file_info['file_name'],
                    open(file_info['path'], 'rb'),
                    file_info['content_type']
                )
            elif isinstance(files, list):
                # 多个文件
                for i, file_path in enumerate(files):
                    file_info = self._prepare_file_data(file_path, f'file_{i}')
                    files_data[file_info['field_name']] = (
                        file_info['file_name'],
                        open(file_info['path'], 'rb'),
                        file_info['content_type']
                    )
            elif isinstance(files, dict):
                # 字典形式的文件映射
                for field_name, file_path in files.items():
                    file_info = self._prepare_file_data(file_path, field_name)
                    files_data[field_name] = (
                        file_info['file_name'],
                        open(file_info['path'], 'rb'),
                        file_info['content_type']
                    )
            
            kwargs['files'] = files_data
            
            # 如果有表单数据，一起发送
            if form_data:
                kwargs['data'] = form_data
            elif data:
                kwargs['data'] = data
                
        elif json_data:
            # JSON 数据
            kwargs['json'] = json_data
            kwargs['headers']['Content-Type'] = 'application/json'
        elif data:
            # 表单数据
            kwargs['data'] = data
            
        try:
            response = self.session.post(**kwargs)
            return response
        finally:
            # 关闭打开的文件
            if 'files' in kwargs:
                for file_tuple in kwargs['files'].values():
                    if hasattr(file_tuple[1], 'close'):
                        file_tuple[1].close()
    
    def get(self, params: Dict[str, Any] = None) -> requests.Response:
        """
        发送 GET 请求
        
        Args:
            params: URL 参数
            
        Returns:
            requests.Response 对象
        """
        kwargs = {
            'url': self.base_url,
            'headers': self.headers,
            'timeout': self.timeout
        }
        
        if params:
            kwargs['params'] = params
            
        return self.session.get(**kwargs)
    
    def upload_image(self, image_path: str, field_name: str = 'image', 
                    additional_data: Dict[str, Any] = None) -> requests.Response:
        """
        上传图片文件
        
        Args:
            image_path: 图片文件路径
            field_name: 表单字段名
            additional_data: 额外的表单数据
            
        Returns:
            requests.Response 对象
        """
        # 验证是否为图片文件
        content_type = self._detect_content_type(image_path)
        if not content_type.startswith('image/'):
            raise ValueError(f"文件不是图片格式: {image_path}")
            
        return self.post(files={field_name: image_path}, form_data=additional_data)
    
    def upload_audio(self, audio_path: str, field_name: str = 'audio',
                    additional_data: Dict[str, Any] = None) -> requests.Response:
        """
        上传音频文件
        
        Args:
            audio_path: 音频文件路径
            field_name: 表单字段名
            additional_data: 额外的表单数据
            
        Returns:
            requests.Response 对象
        """
        # 验证是否为音频文件
        content_type = self._detect_content_type(audio_path)
        if not content_type.startswith('audio/'):
            raise ValueError(f"文件不是音频格式: {audio_path}")
            
        return self.post(files={field_name: audio_path}, form_data=additional_data)
    
    def upload_video(self, video_path: str, field_name: str = 'video',
                    additional_data: Dict[str, Any] = None) -> requests.Response:
        """
        上传视频文件
        
        Args:
            video_path: 视频文件路径
            field_name: 表单字段名
            additional_data: 额外的表单数据
            
        Returns:
            requests.Response 对象
        """
        # 验证是否为视频文件
        content_type = self._detect_content_type(video_path)
        if not content_type.startswith('video/'):
            raise ValueError(f"文件不是视频格式: {video_path}")
            
        return self.post(files={field_name: video_path}, form_data=additional_data)
    
    def upload_document(self, doc_path: str, field_name: str = 'document',
                       additional_data: Dict[str, Any] = None) -> requests.Response:
        """
        上传文档文件
        
        Args:
            doc_path: 文档文件路径
            field_name: 表单字段名
            additional_data: 额外的表单数据
            
        Returns:
            requests.Response 对象
        """
        return self.post(files={field_name: doc_path}, form_data=additional_data)
    
    def upload_multiple_files(self, file_paths: List[str], 
                             field_prefix: str = 'file') -> requests.Response:
        """
        批量上传多个文件
        
        Args:
            file_paths: 文件路径列表
            field_prefix: 字段名前缀
            
        Returns:
            requests.Response 对象
        """
        return self.post(files=file_paths)
    
    def send_base64_data(self, base64_data: str, data_type: str = 'image',
                        additional_data: Dict[str, Any] = None) -> requests.Response:
        """
        发送 Base64 编码的数据
        
        Args:
            base64_data: Base64 编码的数据
            data_type: 数据类型 (image, audio, video, document)
            additional_data: 额外的数据
            
        Returns:
            requests.Response 对象
        """
        payload = {
            'data': base64_data,
            'type': data_type
        }
        
        if additional_data:
            payload.update(additional_data)
            
        return self.post(json_data=payload)
    
    def stream_upload(self, file_path: str, chunk_size: int = 8192) -> requests.Response:
        """
        流式上传大文件
        
        Args:
            file_path: 文件路径
            chunk_size: 块大小（字节）
            
        Returns:
            requests.Response 对象
        """
        def file_generator():
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
        
        file_size = os.path.getsize(file_path)
        content_type = self._detect_content_type(file_path)
        
        headers = self.headers.copy()
        headers.update({
            'Content-Type': content_type,
            'Content-Length': str(file_size),
            'Transfer-Encoding': 'chunked'
        })
        
        return self.session.post(
            self.base_url,
            data=file_generator(),
            headers=headers,
            timeout=self.timeout
        )
    
    def close(self):
        """关闭会话"""
        self.session.close()
