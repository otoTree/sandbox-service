#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HttpClient 使用示例
演示如何使用增强后的 HttpClient 类上传各种类型的文件和数据
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from httpClient import HttpClient
import base64
import os

def main():
    # 初始化客户端
    client = HttpClient(
        base_url="https://httpbin.org/post",  # 测试用的 API 端点
        headers={"User-Agent": "Enhanced-HttpClient/1.0"},
        timeout=30
    )
    
    print("=== HttpClient 增强功能演示 ===\n")
    
    # 1. 发送 JSON 数据
    print("1. 发送 JSON 数据:")
    try:
        response = client.post(json_data={"message": "Hello World", "type": "json"})
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.json()}\n")
    except Exception as e:
        print(f"错误: {e}\n")
    
    # 2. 发送表单数据
    print("2. 发送表单数据:")
    try:
        response = client.post(data={"name": "张三", "age": "25", "city": "北京"})
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.json()}\n")
    except Exception as e:
        print(f"错误: {e}\n")
    
    # 3. 上传单个文件（如果存在的话）
    print("3. 上传单个文件:")
    test_file = "test.txt"
    if create_test_file(test_file):
        try:
            response = client.post(files=test_file, form_data={"description": "测试文件"})
            print(f"状态码: {response.status_code}")
            print(f"响应: {response.json()}\n")
        except Exception as e:
            print(f"错误: {e}\n")
        finally:
            cleanup_file(test_file)
    else:
        print("跳过文件上传测试（无法创建测试文件）\n")
    
    # 4. 上传多个文件
    print("4. 上传多个文件:")
    test_files = ["test1.txt", "test2.txt"]
    if all(create_test_file(f) for f in test_files):
        try:
            response = client.upload_multiple_files(test_files)
            print(f"状态码: {response.status_code}")
            print(f"响应: {response.json()}\n")
        except Exception as e:
            print(f"错误: {e}\n")
        finally:
            for f in test_files:
                cleanup_file(f)
    else:
        print("跳过多文件上传测试（无法创建测试文件）\n")
    
    # 5. 使用字典映射上传文件
    print("5. 使用字典映射上传文件:")
    file_mapping = {"document": "doc.txt", "backup": "backup.txt"}
    if all(create_test_file(f) for f in file_mapping.values()):
        try:
            response = client.post(files=file_mapping, form_data={"project": "demo"})
            print(f"状态码: {response.status_code}")
            print(f"响应: {response.json()}\n")
        except Exception as e:
            print(f"错误: {e}\n")
        finally:
            for f in file_mapping.values():
                cleanup_file(f)
    else:
        print("跳过字典映射上传测试（无法创建测试文件）\n")
    
    # 6. 发送 Base64 编码数据
    print("6. 发送 Base64 编码数据:")
    try:
        # 创建一些示例数据并编码为 Base64
        sample_data = "这是一些示例数据，将被编码为 Base64"
        base64_data = base64.b64encode(sample_data.encode('utf-8')).decode('utf-8')
        
        response = client.send_base64_data(
            base64_data=base64_data,
            data_type="text",
            additional_data={"filename": "sample.txt", "encoding": "utf-8"}
        )
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.json()}\n")
    except Exception as e:
        print(f"错误: {e}\n")
    
    # 7. GET 请求示例
    print("7. GET 请求示例:")
    try:
        get_client = HttpClient("https://httpbin.org/get")
        response = get_client.get(params={"param1": "value1", "param2": "测试参数"})
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.json()}\n")
    except Exception as e:
        print(f"错误: {e}\n")
    
    # 8. 专用方法演示（创建测试图片文件）
    print("8. 专用上传方法演示:")
    test_image = create_test_image()
    if test_image:
        try:
            # 上传图片
            response = client.upload_image(test_image, additional_data={"title": "测试图片"})
            print(f"图片上传状态码: {response.status_code}")
        except Exception as e:
            print(f"图片上传错误: {e}")
        finally:
            cleanup_file(test_image)
    
    # 关闭客户端
    client.close()
    print("=== 演示完成 ===")

def create_test_file(filename: str) -> bool:
    """创建测试文件"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"这是测试文件 {filename}\n")
            f.write("包含一些示例内容用于测试上传功能。\n")
            f.write("创建时间: " + str(os.path.getctime))
        return True
    except Exception as e:
        print(f"无法创建测试文件 {filename}: {e}")
        return False

def create_test_image() -> str:
    """创建一个简单的 SVG 测试图片"""
    filename = "test_image.svg"
    try:
        svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="lightblue"/>
  <text x="50" y="50" text-anchor="middle" dy=".3em" font-family="Arial" font-size="12">测试图片</text>
</svg>'''
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(svg_content)
        return filename
    except Exception as e:
        print(f"无法创建测试图片: {e}")
        return None

def cleanup_file(filename: str):
    """清理测试文件"""
    try:
        if os.path.exists(filename):
            os.remove(filename)
    except Exception as e:
        print(f"清理文件 {filename} 时出错: {e}")

if __name__ == "__main__":
    main()