"""
循环封装类使用示例
演示 LoopWrapper 类的各种使用方法
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from system import LoopWrapper, loop_execute, loop_execute_with_condition
import random
import time


def example_simple_function():
    """简单的示例函数"""
    print(f"执行时间: {time.strftime('%H:%M:%S')}")
    return random.randint(1, 100)


def example_function_with_params(name: str, value: int):
    """带参数的示例函数"""
    result = value * 2
    print(f"{name}: {value} * 2 = {result}")
    return result


def example_function_with_error():
    """可能出错的示例函数"""
    if random.random() < 0.3:  # 30% 概率出错
        raise ValueError("随机错误发生了!")
    return "成功执行"


def example_function_early_exit():
    """可能提前退出的函数"""
    value = random.randint(1, 10)
    print(f"生成的值: {value}")
    if value > 8:  # 值大于8时返回False，提前结束循环
        print("值太大了，提前结束!")
        return False
    return value


def main():
    print("=" * 60)
    print("循环封装类使用示例")
    print("=" * 60)
    
    # 示例1: 基本使用
    print("\n1. 基本使用 - 执行5次简单函数")
    wrapper = LoopWrapper(max_iterations=5, log_progress=True)
    result = wrapper.execute(example_simple_function)
    print(f"执行结果: 总共执行 {result['total_iterations']} 次")
    print(f"成功次数: {result['success_count']}, 错误次数: {result['error_count']}")
    print(f"执行时间: {result['execution_time']:.2f} 秒")
    
    # 示例2: 带参数的函数
    print("\n2. 带参数的函数 - 执行3次")
    wrapper = LoopWrapper(max_iterations=3, delay=0.5, log_progress=True)
    result = wrapper.execute(example_function_with_params, "测试", 10)
    print(f"执行结果: {result['success_count']} 次成功")
    
    # 示例3: 错误处理
    print("\n3. 错误处理 - 可能出错的函数")
    wrapper = LoopWrapper(max_iterations=10, stop_on_error=False, log_progress=True)
    result = wrapper.execute(example_function_with_error)
    print(f"执行结果: 成功 {result['success_count']} 次, 错误 {result['error_count']} 次")
    if result['errors']:
        print("错误详情:")
        for error in result['errors']:
            print(f"  第{error['iteration']}次: {error['error']}")
    
    # 示例4: 遇到错误时停止
    print("\n4. 遇到错误时停止")
    wrapper = LoopWrapper(max_iterations=10, stop_on_error=True, log_progress=True)
    result = wrapper.execute(example_function_with_error)
    print(f"执行结果: 在第 {result['total_iterations']} 次后停止")
    
    # 示例5: 提前退出
    print("\n5. 函数返回False时提前退出")
    wrapper = LoopWrapper(max_iterations=20, log_progress=True)
    result = wrapper.execute(example_function_early_exit)
    print(f"执行结果: 在第 {result['total_iterations']} 次后结束")
    print(f"是否完成所有循环: {result['completed']}")
    
    # 示例6: 带条件的循环
    print("\n6. 带条件的循环执行")
    counter = 0
    def condition_func():
        nonlocal counter
        counter += 1
        return counter <= 3  # 只允许执行3次
    
    def simple_task():
        return f"任务执行第 {counter} 次"
    
    wrapper = LoopWrapper(max_iterations=10, log_progress=True)
    result = wrapper.execute_with_condition(simple_task, condition_func)
    print(f"条件循环结果: 执行了 {result['total_iterations']} 次")
    
    # 示例7: 使用便捷函数
    print("\n7. 使用便捷函数")
    result = loop_execute(
        example_simple_function,
        max_iterations=3,
        delay=0.2,
        log_progress=True
    )
    print(f"便捷函数执行结果: {result['success_count']} 次成功")
    
    # 示例8: 带条件的便捷函数
    print("\n8. 带条件的便捷函数")
    attempts = 0
    def retry_condition():
        nonlocal attempts
        attempts += 1
        return attempts <= 5
    
    def network_request_simulation():
        # 模拟网络请求，70%成功率
        if random.random() < 0.7:
            return "请求成功"
        else:
            raise ConnectionError("网络连接失败")
    
    result = loop_execute_with_condition(
        network_request_simulation,
        retry_condition,
        max_iterations=10,
        stop_on_error=False,
        log_progress=True
    )
    print(f"网络请求模拟: 尝试 {result['total_iterations']} 次, 成功 {result['success_count']} 次")
    
    # 示例9: 获取统计信息
    print("\n9. 获取统计信息")
    wrapper = LoopWrapper(max_iterations=5)
    wrapper.execute(example_simple_function)
    stats = wrapper.get_stats()
    print(f"统计信息: {stats}")
    
    print("\n" + "=" * 60)
    print("所有示例执行完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()