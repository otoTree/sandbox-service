#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM多模态支持模块
支持文本、图像、音频、视频等多种媒体类型的处理
"""

import os
import base64
import mimetypes
from typing import Dict, List, Optional, Union, Any, BinaryIO
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import json
import logging

from .llm_client import Message, MessageRole, BaseLLMClient


class MediaType(Enum):
    """媒体类型枚举"""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    DOCUMENT = "document"
    URL = "url"


class ImageFormat(Enum):
    """图像格式枚举"""
    JPEG = "jpeg"
    PNG = "png"
    GIF = "gif"
    WEBP = "webp"
    BMP = "bmp"
    TIFF = "tiff"


class AudioFormat(Enum):
    """音频格式枚举"""
    MP3 = "mp3"
    WAV = "wav"
    FLAC = "flac"
    AAC = "aac"
    OGG = "ogg"
    M4A = "m4a"


@dataclass
class MediaContent:
    """媒体内容数据类"""
    media_type: MediaType
    content: Union[str, bytes]
    format: Optional[str] = None
    encoding: str = "utf-8"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_base64(self) -> str:
        """转换为base64编码"""
        if isinstance(self.content, str):
            return base64.b64encode(self.content.encode(self.encoding)).decode('ascii')
        else:
            return base64.b64encode(self.content).decode('ascii')
    
    def get_mime_type(self) -> str:
        """获取MIME类型"""
        if self.media_type == MediaType.IMAGE:
            return f"image/{self.format or 'jpeg'}"
        elif self.media_type == MediaType.AUDIO:
            return f"audio/{self.format or 'mp3'}"
        elif self.media_type == MediaType.VIDEO:
            return f"video/{self.format or 'mp4'}"
        elif self.media_type == MediaType.DOCUMENT:
            return f"application/{self.format or 'pdf'}"
        else:
            return "text/plain"


@dataclass
class MultiModalMessage:
    """多模态消息数据类"""
    role: MessageRole
    contents: List[MediaContent]
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_openai_format(self) -> Dict[str, Any]:
        """转换为OpenAI格式"""
        content_list = []
        
        for media in self.contents:
            if media.media_type == MediaType.TEXT:
                content_list.append({
                    "type": "text",
                    "text": media.content
                })
            elif media.media_type == MediaType.IMAGE:
                content_list.append({
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{media.get_mime_type()};base64,{media.to_base64()}"
                    }
                })
            elif media.media_type == MediaType.URL:
                content_list.append({
                    "type": "image_url",
                    "image_url": {
                        "url": media.content
                    }
                })
        
        return {
            "role": self.role.value,
            "content": content_list
        }
    
    def to_claude_format(self) -> Dict[str, Any]:
        """转换为Claude格式"""
        content_list = []
        
        for media in self.contents:
            if media.media_type == MediaType.TEXT:
                content_list.append({
                    "type": "text",
                    "text": media.content
                })
            elif media.media_type == MediaType.IMAGE:
                content_list.append({
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media.get_mime_type(),
                        "data": media.to_base64()
                    }
                })
        
        return {
            "role": self.role.value,
            "content": content_list
        }
    
    def get_text_content(self) -> str:
        """获取文本内容"""
        text_parts = []
        for media in self.contents:
            if media.media_type == MediaType.TEXT:
                text_parts.append(media.content)
        return " ".join(text_parts)


class MediaProcessor:
    """媒体处理器"""
    
    def __init__(self):
        self.logger = logging.getLogger(f"{__name__}.MediaProcessor")
        
        # 支持的文件格式
        self.image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff'}
        self.audio_extensions = {'.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a'}
        self.video_extensions = {'.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'}
        self.document_extensions = {'.pdf', '.doc', '.docx', '.txt', '.rtf'}
    
    def detect_media_type(self, file_path: str) -> MediaType:
        """检测媒体类型"""
        ext = Path(file_path).suffix.lower()
        
        if ext in self.image_extensions:
            return MediaType.IMAGE
        elif ext in self.audio_extensions:
            return MediaType.AUDIO
        elif ext in self.video_extensions:
            return MediaType.VIDEO
        elif ext in self.document_extensions:
            return MediaType.DOCUMENT
        else:
            return MediaType.TEXT
    
    def load_file(self, file_path: str) -> MediaContent:
        """加载文件"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        media_type = self.detect_media_type(file_path)
        file_ext = Path(file_path).suffix.lower().lstrip('.')
        
        # 获取文件信息
        file_stat = os.stat(file_path)
        metadata = {
            'file_path': file_path,
            'file_size': file_stat.st_size,
            'file_name': Path(file_path).name
        }
        
        if media_type == MediaType.TEXT:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return MediaContent(
                media_type=media_type,
                content=content,
                format=file_ext,
                metadata=metadata
            )
        else:
            with open(file_path, 'rb') as f:
                content = f.read()
            return MediaContent(
                media_type=media_type,
                content=content,
                format=file_ext,
                metadata=metadata
            )
    
    def create_text_content(self, text: str) -> MediaContent:
        """创建文本内容"""
        return MediaContent(
            media_type=MediaType.TEXT,
            content=text,
            format="plain"
        )
    
    def create_url_content(self, url: str) -> MediaContent:
        """创建URL内容"""
        return MediaContent(
            media_type=MediaType.URL,
            content=url,
            format="url",
            metadata={'url': url}
        )
    
    def resize_image(self, image_content: MediaContent, max_size: int = 1024) -> MediaContent:
        """调整图像大小（需要PIL库）"""
        try:
            from PIL import Image
            import io
            
            if image_content.media_type != MediaType.IMAGE:
                raise ValueError("只能调整图像大小")
            
            # 从bytes创建图像
            image = Image.open(io.BytesIO(image_content.content))
            
            # 计算新尺寸
            width, height = image.size
            if max(width, height) > max_size:
                ratio = max_size / max(width, height)
                new_width = int(width * ratio)
                new_height = int(height * ratio)
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # 转换回bytes
            output = io.BytesIO()
            format_name = image_content.format.upper()
            if format_name == 'JPG':
                format_name = 'JPEG'
            
            image.save(output, format=format_name)
            resized_content = output.getvalue()
            
            # 更新元数据
            new_metadata = image_content.metadata.copy()
            new_metadata.update({
                'original_size': (width, height),
                'resized_size': (new_width, new_height),
                'resized': True
            })
            
            return MediaContent(
                media_type=image_content.media_type,
                content=resized_content,
                format=image_content.format,
                encoding=image_content.encoding,
                metadata=new_metadata
            )
            
        except ImportError:
            self.logger.warning("PIL库未安装，无法调整图像大小")
            return image_content
        except Exception as e:
            self.logger.error(f"调整图像大小失败: {e}")
            return image_content
    
    def extract_audio_info(self, audio_content: MediaContent) -> Dict[str, Any]:
        """提取音频信息（需要mutagen库）"""
        try:
            from mutagen import File
            import io
            
            if audio_content.media_type != MediaType.AUDIO:
                raise ValueError("只能处理音频文件")
            
            # 创建临时文件来分析
            temp_path = f"temp_audio.{audio_content.format}"
            with open(temp_path, 'wb') as f:
                f.write(audio_content.content)
            
            try:
                audio_file = File(temp_path)
                if audio_file is not None:
                    info = {
                        'duration': getattr(audio_file.info, 'length', 0),
                        'bitrate': getattr(audio_file.info, 'bitrate', 0),
                        'sample_rate': getattr(audio_file.info, 'sample_rate', 0),
                        'channels': getattr(audio_file.info, 'channels', 0)
                    }
                    
                    # 添加标签信息
                    if audio_file.tags:
                        info['tags'] = dict(audio_file.tags)
                    
                    return info
            finally:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            
        except ImportError:
            self.logger.warning("mutagen库未安装，无法提取音频信息")
        except Exception as e:
            self.logger.error(f"提取音频信息失败: {e}")
        
        return {}


class MultiModalClient:
    """多模态LLM客户端"""
    
    def __init__(self, base_client: BaseLLMClient):
        self.base_client = base_client
        self.media_processor = MediaProcessor()
        self.logger = logging.getLogger(f"{__name__}.MultiModalClient")
    
    def create_multimodal_message(self, role: MessageRole, 
                                 text: str = "", 
                                 files: List[str] = None,
                                 urls: List[str] = None) -> MultiModalMessage:
        """创建多模态消息"""
        contents = []
        
        # 添加文本内容
        if text:
            contents.append(self.media_processor.create_text_content(text))
        
        # 添加文件内容
        if files:
            for file_path in files:
                try:
                    media_content = self.media_processor.load_file(file_path)
                    
                    # 如果是图像，可以选择调整大小
                    if media_content.media_type == MediaType.IMAGE:
                        media_content = self.media_processor.resize_image(media_content)
                    
                    contents.append(media_content)
                except Exception as e:
                    self.logger.error(f"加载文件失败 {file_path}: {e}")
        
        # 添加URL内容
        if urls:
            for url in urls:
                contents.append(self.media_processor.create_url_content(url))
        
        return MultiModalMessage(role=role, contents=contents)
    
    def chat_with_media(self, text: str, 
                       files: List[str] = None,
                       urls: List[str] = None,
                       conversation_history: List[MultiModalMessage] = None,
                       **kwargs) -> str:
        """使用多媒体进行聊天"""
        # 创建用户消息
        user_message = self.create_multimodal_message(
            role=MessageRole.USER,
            text=text,
            files=files,
            urls=urls
        )
        
        # 构建消息历史
        messages = []
        if conversation_history:
            for msg in conversation_history:
                messages.append(self._convert_to_standard_message(msg))
        
        messages.append(self._convert_to_standard_message(user_message))
        
        # 发送请求
        response = self.base_client.chat(messages, **kwargs)
        return response.content
    
    def _convert_to_standard_message(self, multimodal_msg: MultiModalMessage) -> Message:
        """将多模态消息转换为标准消息格式"""
        # 根据客户端类型选择合适的格式
        if hasattr(self.base_client, 'config') and self.base_client.config.provider.value == 'openai':
            content = json.dumps(multimodal_msg.to_openai_format()['content'])
        elif hasattr(self.base_client, 'config') and self.base_client.config.provider.value == 'claude':
            content = json.dumps(multimodal_msg.to_claude_format()['content'])
        else:
            # 对于不支持多模态的客户端，只使用文本内容
            content = multimodal_msg.get_text_content()
        
        return Message(
            role=multimodal_msg.role,
            content=content,
            metadata=multimodal_msg.metadata
        )
    
    def analyze_image(self, image_path: str, prompt: str = "请描述这张图片") -> str:
        """分析图像"""
        return self.chat_with_media(
            text=prompt,
            files=[image_path]
        )
    
    def transcribe_audio(self, audio_path: str, prompt: str = "请转录这段音频") -> str:
        """转录音频（需要支持音频的模型）"""
        return self.chat_with_media(
            text=prompt,
            files=[audio_path]
        )
    
    def analyze_document(self, doc_path: str, prompt: str = "请总结这个文档") -> str:
        """分析文档"""
        return self.chat_with_media(
            text=prompt,
            files=[doc_path]
        )
    
    def compare_images(self, image_paths: List[str], prompt: str = "请比较这些图片") -> str:
        """比较多张图片"""
        return self.chat_with_media(
            text=prompt,
            files=image_paths
        )
    
    def web_content_analysis(self, urls: List[str], prompt: str = "请分析这些网页内容") -> str:
        """分析网页内容"""
        return self.chat_with_media(
            text=prompt,
            urls=urls
        )


class BatchProcessor:
    """批量处理器"""
    
    def __init__(self, multimodal_client: MultiModalClient):
        self.client = multimodal_client
        self.logger = logging.getLogger(f"{__name__}.BatchProcessor")
    
    def process_image_batch(self, image_dir: str, prompt: str = "请描述这张图片") -> Dict[str, str]:
        """批量处理图片"""
        results = {}
        image_files = []
        
        # 收集图片文件
        for ext in self.client.media_processor.image_extensions:
            image_files.extend(Path(image_dir).glob(f"*{ext}"))
        
        for image_file in image_files:
            try:
                result = self.client.analyze_image(str(image_file), prompt)
                results[str(image_file)] = result
                self.logger.info(f"处理完成: {image_file}")
            except Exception as e:
                self.logger.error(f"处理失败 {image_file}: {e}")
                results[str(image_file)] = f"错误: {e}"
        
        return results
    
    def generate_media_report(self, media_dir: str) -> Dict[str, Any]:
        """生成媒体文件报告"""
        report = {
            'total_files': 0,
            'by_type': {},
            'by_format': {},
            'total_size': 0,
            'files': []
        }
        
        for file_path in Path(media_dir).rglob('*'):
            if file_path.is_file():
                try:
                    media_content = self.client.media_processor.load_file(str(file_path))
                    
                    report['total_files'] += 1
                    report['total_size'] += media_content.metadata.get('file_size', 0)
                    
                    # 按类型统计
                    media_type = media_content.media_type.value
                    report['by_type'][media_type] = report['by_type'].get(media_type, 0) + 1
                    
                    # 按格式统计
                    format_name = media_content.format
                    report['by_format'][format_name] = report['by_format'].get(format_name, 0) + 1
                    
                    # 文件信息
                    report['files'].append({
                        'path': str(file_path),
                        'type': media_type,
                        'format': format_name,
                        'size': media_content.metadata.get('file_size', 0)
                    })
                    
                except Exception as e:
                    self.logger.error(f"处理文件失败 {file_path}: {e}")
        
        return report


# 便捷函数
def create_image_message(text: str, image_path: str) -> MultiModalMessage:
    """创建图像消息的便捷函数"""
    processor = MediaProcessor()
    contents = [
        processor.create_text_content(text),
        processor.load_file(image_path)
    ]
    return MultiModalMessage(role=MessageRole.USER, contents=contents)


def create_mixed_message(text: str, files: List[str] = None, urls: List[str] = None) -> MultiModalMessage:
    """创建混合媒体消息的便捷函数"""
    processor = MediaProcessor()
    contents = [processor.create_text_content(text)]
    
    if files:
        for file_path in files:
            contents.append(processor.load_file(file_path))
    
    if urls:
        for url in urls:
            contents.append(processor.create_url_content(url))
    
    return MultiModalMessage(role=MessageRole.USER, contents=contents)