# LLM客户端

一个功能强大、易于使用的Python LLM（大语言模型）客户端库，支持多个主流LLM提供商。

## 特性

- 🚀 **多提供商支持**: OpenAI、Claude、本地LLM等
- 🎯 **统一接口**: 一致的API设计，轻松切换不同提供商
- 🖼️ **多模态支持**: 支持文本、图像、音频等多种媒体类型
- 💬 **对话管理**: 内置对话历史管理和上下文维护
- 🔧 **高度可配置**: 灵活的配置选项和自定义设置
- 🛡️ **错误处理**: 完善的错误处理和重试机制
- 📊 **使用统计**: 详细的token使用和响应时间统计

## 快速开始

### 安装

```bash
pip install -r requirements.txt
```

### 基础使用

```python
from llm_client import LLMClientFactory, create_message, create_conversation

# 创建OpenAI客户端
client = LLMClientFactory.create_openai_client(
    api_key="your-openai-api-key",
    model="gpt-3.5-turbo"
)

# 创建对话
messages = create_conversation("你是一个有用的AI助手。")
messages.append(create_message("user", "你好！"))

# 发送请求
response = client.chat(messages)
print(f"AI回复: {response.content}")
```

## 项目结构

```
llm_client/
├── llm_client.py          # 核心LLM客户端
├── llm_multimodal.py      # 多模态支持
├── example_llm_usage.py   # 使用示例
├── test_llm_client.py     # 测试文件
├── requirements.txt       # 依赖包
└── README.md             # 项目文档
```

## 详细使用指南

### 1. 支持的LLM提供商

#### OpenAI

```python
from llm_client import LLMClientFactory

client = LLMClientFactory.create_openai_client(
    api_key="your-api-key",
    model="gpt-4",  # 或 gpt-3.5-turbo
    temperature=0.7,
    max_tokens=1000
)
```

#### Claude (Anthropic)

```python
client = LLMClientFactory.create_claude_client(
    api_key="your-claude-api-key",
    model="claude-3-sonnet-20240229",
    temperature=0.7
)
```

#### 本地LLM (如Ollama)

```python
client = LLMClientFactory.create_local_client(
    base_url="http://localhost:11434/api/chat",
    model="llama2"
)
```

### 2. 消息类型

#### 基础消息

```python
from llm_client import create_message, MessageRole

# 系统消息
system_msg = create_message("system", "你是一个专业的翻译助手。")

# 用户消息
user_msg = create_message("user", "请将这句话翻译成英文：你好世界")

# 助手消息
assistant_msg = create_message("assistant", "Hello World")
```

#### 对话创建

```python
from llm_client import create_conversation

# 创建带系统提示的对话
conversation = create_conversation("你是一个有用的AI助手。")

# 添加用户消息
conversation.append(create_message("user", "什么是人工智能？"))
```

### 3. 多模态功能

#### 图像分析

```python
from llm_multimodal import MultiModalClient, create_image_message

# 创建支持多模态的客户端
base_client = LLMClientFactory.create_openai_client(
    api_key="your-api-key",
    model="gpt-4-vision-preview"
)
multimodal_client = MultiModalClient(base_client)

# 分析图像
response = multimodal_client.chat_with_image(
    image_path="path/to/image.jpg",
    prompt="请描述这张图片的内容"
)
```

#### 混合媒体消息

```python
from llm_multimodal import create_mixed_message, MediaProcessor

processor = MediaProcessor()

# 创建包含文本和图像的消息
message = create_mixed_message(
    text="请分析这张图片",
    media_files=["image1.jpg", "document.pdf"]
)
```

### 4. 高级功能

#### 批量处理

```python
questions = [
    "什么是机器学习？",
    "Python有什么优势？",
    "如何学习编程？"
]

for question in questions:
    messages = [create_message("user", question)]
    response = client.chat(messages)
    print(f"问题: {question}")
    print(f"回答: {response.content}")
```

#### 对话历史管理

```python
# 维护对话历史
conversation_history = create_conversation("你是一个友好的助手。")

# 多轮对话
questions = ["我叫张三", "我的名字是什么？"]

for question in questions:
    conversation_history.append(create_message("user", question))
    response = client.chat(conversation_history)
    
    # 将AI回复添加到历史
    conversation_history.append(create_message("assistant", response.content))
```

#### 错误处理

```python
try:
    response = client.chat(messages)
    print(response.content)
except Exception as e:
    print(f"请求失败: {e}")
    # 实现重试逻辑或错误恢复
```

## 测试

运行测试套件：

```bash
python test_llm_client.py
```

测试包括：
- 单元测试：各个组件的功能测试
- 集成测试：端到端工作流测试
- 性能测试：响应时间和吞吐量测试
- 模拟测试：API调用的模拟测试

## 环境配置

### 环境变量

创建 `.env` 文件：

```bash
# OpenAI配置
OPENAI_API_KEY=your-openai-api-key
OPENAI_BASE_URL=https://api.openai.com/v1

# Claude配置
CLAUDE_API_KEY=your-claude-api-key

# 本地LLM配置
LOCAL_LLM_URL=http://localhost:11434
```

### 配置文件

```python
# config.py
LLM_CONFIG = {
    "openai": {
        "api_key": "your-key",
        "model": "gpt-3.5-turbo",
        "temperature": 0.7,
        "max_tokens": 1000
    },
    "claude": {
        "api_key": "your-key",
        "model": "claude-3-sonnet-20240229"
    }
}
```

## 性能优化

### 1. 连接池

```python
# HttpClient已内置连接池和性能优化
from httpClient import HttpClient

# 创建HttpClient实例，自动管理连接池
client = HttpClient(
    base_url="https://api.example.com",
    timeout=30
)

# 使用统一的网络请求接口
response = client.post(json_data={"key": "value"})
```

### 2. 异步处理

```python
import asyncio
import aiohttp

async def async_chat(client, messages):
    """异步聊天请求"""
    # 实现异步请求逻辑
    pass
```

### 3. 缓存机制

```python
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_chat(message_hash):
    """缓存常见请求的响应"""
    pass
```

## 故障排除

### 常见问题

1. **API密钥错误**
   ```
   错误: 401 Unauthorized
   解决: 检查API密钥是否正确设置
   ```

2. **网络连接问题**
   ```
   错误: Connection timeout
   解决: 检查网络连接，考虑使用代理
   ```

3. **模型不存在**
   ```
   错误: Model not found
   解决: 确认模型名称正确，检查账户权限
   ```

4. **Token限制**
   ```
   错误: Token limit exceeded
   解决: 减少输入长度或增加max_tokens设置
   ```

### 调试技巧

1. **启用详细日志**
   ```python
   import logging
   logging.basicConfig(level=logging.DEBUG)
   ```

2. **检查请求内容**
   ```python
   print(f"发送消息: {messages}")
   print(f"响应内容: {response.content}")
   ```

3. **监控API使用**
   ```python
   print(f"Token使用: {response.usage}")
   print(f"响应时间: {response.response_time}秒")
   ```

## 贡献指南

欢迎贡献代码！请遵循以下步骤：

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建Pull Request

### 开发环境设置

```bash
# 克隆项目
git clone https://github.com/your-username/llm-client.git
cd llm-client

# 安装开发依赖
pip install -r requirements.txt

# 运行测试
python -m pytest test_llm_client.py -v

# 代码格式化
black llm_client.py
flake8 llm_client.py
```

### 代码规范

- 使用Python 3.7+
- 遵循PEP 8代码风格
- 添加类型注解
- 编写单元测试
- 更新文档

## 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 支持OpenAI、Claude、本地LLM
- 多模态功能
- 完整的测试套件

## 支持

如果您遇到问题或有建议，请：

1. 查看[常见问题](#故障排除)
2. 搜索现有的[Issues](https://github.com/your-username/llm-client/issues)
3. 创建新的Issue描述问题
4. 联系维护者

---

**注意**: 使用本库需要相应LLM服务的API密钥。请确保遵守各服务提供商的使用条款和限制。